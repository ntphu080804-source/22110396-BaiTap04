<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>
		<!DOCTYPE html>
		<html>

		<head>
			<title>Hồ sơ cá nhân - ${sessionScope.account.fullName}</title>
		</head>

		<body>
			<div class="row justify-content-center">
				<div class="col-md-7">
					<div class="card shadow-sm">
						<div class="card-header bg-primary text-white">
							<h5 class="mb-0">Cập Nhật Hồ Sơ Cá Nhân</h5>
						</div>
						<div class="card-body">
							<c:if test="${not empty msg}">
								<div class="alert alert-success">${msg}</div>
							</c:if>
							<c:if test="${not empty sessionScope.msg}">
								<div class="alert alert-success">${sessionScope.msg}</div>
								<c:remove var="msg" scope="session" />
							</c:if>
							<c:if test="${not empty err}">
								<div class="alert alert-danger">${err}</div>
							</c:if>

							<form action="<c:url value='/user/profile'/>" method="post" enctype="multipart/form-data">
								<div class="text-center mb-4">
									<c:choose>
										<c:when test="${not empty sessionScope.account.avatar}">
											<img src="${sessionScope.account.avatar}"
												class="rounded-circle border shadow-sm" width="120" height="120"
												style="object-fit: cover;">
										</c:when>
										<c:otherwise>
											<img src="https://via.placeholder.com/120?text=Avatar"
												class="rounded-circle border" width="120" height="120">
										</c:otherwise>
									</c:choose>
									<div class="mt-2">
										<label class="form-label small text-muted">Đổi ảnh đại diện (Upload lên
											Cloudinary)</label>
										<input type="file" name="imageFile" class="form-control form-control-sm mx-auto"
											style="max-width: 320px;" accept="image/*">
									</div>
								</div>

								<div class="mb-3">
									<label class="form-label">Tên đăng nhập</label>
									<input type="text" class="form-control bg-light"
										value="${sessionScope.account.userName}" readonly>
								</div>

								<div class="mb-3">
									<label class="form-label">Họ và tên <span class="text-danger">*</span></label>
									<input type="text" name="fullName" class="form-control"
										value="${sessionScope.account.fullName}" required minlength="2" maxlength="100">
								</div>

								<div class="mb-3">
									<label class="form-label">Số điện thoại</label>
									<input type="text" name="phone" class="form-control"
										value="${sessionScope.account.phone}" pattern="^(0|\+84)[0-9]{9,10}$"
										title="Nhập số điện thoại hợp lệ (10-11 số)">
								</div>

								<div class="mb-3">
									<label class="form-label">Email <span class="text-danger">*</span></label>
									<input type="email" name="email" class="form-control"
										value="${sessionScope.account.email}" required>
									<div class="form-text text-warning">
										Lưu ý: Nếu thay đổi sang Email mới, hệ thống sẽ gửi mã OTP 6 số tới Email mới để
										xác nhận.
									</div>
								</div>

								<button type="submit" class="btn btn-primary w-100">Lưu thay đổi</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</body>

		</html>