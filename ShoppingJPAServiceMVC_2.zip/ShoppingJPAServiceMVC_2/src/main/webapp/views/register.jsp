<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>
		<!DOCTYPE html>
		<html>

		<head>
			<meta charset="UTF-8">
			<title>Đăng ký tài khoản</title>
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
		</head>

		<body class="bg-light d-flex align-items-center" style="height: 100vh;">
			<div class="container">
				<div class="card mx-auto shadow-sm" style="max-width: 450px;">
					<div class="card-header bg-success text-white text-center">
						<h4 class="mb-0">ĐĂNG KÝ TÀI KHOẢN</h4>
					</div>
					<div class="card-body">
						<c:if test="${not empty alert}">
							<div class="alert alert-danger">${alert}</div>
						</c:if>
						<form action="<c:url value='/register'/>" method="post">
							<div class="mb-3">
								<label class="form-label">Tài khoản (*)</label>
								<input type="text" name="username" class="form-control" required>
							</div>
							<div class="mb-3">
								<label class="form-label">Mật khẩu (*)</label>
								<input type="password" name="password" class="form-control" required>
							</div>
							<div class="mb-3">
								<label class="form-label">Họ và tên</label>
								<input type="text" name="fullname" class="form-control">
							</div>
							<div class="mb-3">
								<label class="form-label">Email</label>
								<input type="email" name="email" class="form-control">
							</div>
							<div class="mb-3">
								<label class="form-label">Số điện thoại</label>
								<input type="text" name="phone" class="form-control">
							</div>
							<button type="submit" class="btn btn-success w-100">Đăng ký</button>
						</form>
						<div class="text-center mt-3">
							<a href="<c:url value='/login'/>">Đã có tài khoản? Đăng nhập</a>
						</div>
					</div>
				</div>
			</div>
		</body>

		</html>