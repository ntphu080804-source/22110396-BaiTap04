<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>
		<!DOCTYPE html>
		<html>

		<head>
			<meta charset="UTF-8">
			<title>Xác thực OTP</title>
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
		</head>

		<body class="bg-light d-flex align-items-center" style="height: 100vh;">
			<div class="container">
				<div class="card mx-auto shadow-sm" style="max-width: 400px;">
					<div class="card-header bg-warning text-dark text-center">
						<h5 class="mb-0">KÍCH HOẠT TÀI KHOẢN OTP</h5>
					</div>
					<div class="card-body">
						<p class="text-muted">Mã OTP đã được gửi tới email:
							<strong>${sessionScope.pendingEmail}</strong></p>
						<c:if test="${not empty alert}">
							<div class="alert alert-danger">${alert}</div>
						</c:if>
						<form action="<c:url value='/verify-otp'/>" method="post">
							<div class="mb-3">
								<label class="form-label">Nhập mã OTP (6 số)</label>
								<input type="text" name="otp" class="form-control text-center fs-4" maxlength="6"
									required>
							</div>
							<button type="submit" class="btn btn-warning w-100 fw-bold">Xác nhận kích hoạt</button>
						</form>
					</div>
				</div>
			</div>
		</body>

		</html>