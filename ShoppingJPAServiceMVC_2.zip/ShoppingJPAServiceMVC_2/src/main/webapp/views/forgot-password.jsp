<!-- views/forgot-password.jsp -->
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>
		<!DOCTYPE html>
		<html>

		<head>
			<meta charset="UTF-8">
			<title>Quên mật khẩu</title>
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
		</head>

		<body class="bg-light d-flex align-items-center" style="height: 100vh;">
			<div class="container">
				<div class="card mx-auto shadow-sm" style="max-width: 400px;">
					<div class="card-header bg-info text-white text-center">
						<h5 class="mb-0">QUÊN MẬT KHẨU</h5>
					</div>
					<div class="card-body">
						<c:if test="${not empty alert}">
							<div class="alert alert-danger">${alert}</div>
						</c:if>
						<form action="<c:url value='/forgot-password'/>" method="post">
							<div class="mb-3">
								<label class="form-label">Nhập Email đã đăng ký</label>
								<input type="email" name="email" class="form-control" required>
							</div>
							<button type="submit" class="btn btn-info text-white w-100">Gửi mã OTP</button>
						</form>
						<div class="text-center mt-3"><a href="<c:url value='/login'/>">Quay lại đăng nhập</a></div>
					</div>
				</div>
			</div>
		</body>

		</html>