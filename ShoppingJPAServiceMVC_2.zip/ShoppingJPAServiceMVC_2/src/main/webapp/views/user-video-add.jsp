<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>
		<!DOCTYPE html>
		<html>

		<head>
			<meta charset="UTF-8">
			<title>Đăng Video Mới</title>
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
		</head>

		<body class="container py-4">
			<div class="card mx-auto shadow-sm" style="max-width: 600px;">
				<div class="card-header bg-success text-white">
					<h5 class="mb-0">Đăng Video Mới (${sessionScope.account.fullName})</h5>
				</div>
				<div class="card-body">
					<form action="<c:url value='/user/video/insert'/>" method="post" enctype="multipart/form-data">
						<div class="mb-3">
							<label class="form-label">Mã Video (VideoId)</label>
							<input type="text" name="videoId" class="form-control" placeholder="Ví dụ: VID001" required>
						</div>
						<div class="mb-3">
							<label class="form-label">Tiêu đề Video</label>
							<input type="text" name="title" class="form-control" required>
						</div>
						<div class="mb-3">
							<label class="form-label">Danh mục</label>
							<select name="categoryId" class="form-select">
								<c:forEach items="${categories}" var="c">
									<option value="${c.categoryid}">${c.categoryname}</option>
								</c:forEach>
							</select>
						</div>
						<div class="mb-3">
							<label class="form-label">Upload Ảnh Poster</label>
							<input type="file" name="posterFile" class="form-control" accept="image/*">
						</div>
						<div class="mb-3">
							<label class="form-label">Upload File Video (.mp4)</label>
							<input type="file" name="videoFile" class="form-control" accept="video/mp4">
						</div>
						<div class="mb-3">
							<label class="form-label">Hoặc nhập Link Video Embed (Youtube/MP4)</label>
							<input type="text" name="videoLink" class="form-control"
								placeholder="https://www.youtube.com/embed/...">
						</div>
						<div class="mb-3">
							<label class="form-label">Mô tả</label>
							<textarea name="description" class="form-control" rows="3"></textarea>
						</div>
						<input type="hidden" name="active" value="1">
						<button type="submit" class="btn btn-success">Đăng Video</button>
						<a href="<c:url value='/video'/>" class="btn btn-secondary">Hủy</a>
					</form>
				</div>
			</div>
		</body>

		</html>