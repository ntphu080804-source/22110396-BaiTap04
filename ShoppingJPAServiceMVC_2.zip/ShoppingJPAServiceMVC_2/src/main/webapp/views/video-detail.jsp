<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>
		<!DOCTYPE html>
		<html>

		<head>
			<meta charset="UTF-8">
			<title>${video.title}</title>
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
		</head>

		<body class="container py-4">
			<div class="mb-3">
				<a href="<c:url value='/home'/>" class="btn btn-outline-secondary btn-sm">« Quay lại Trang chủ</a>
				<a href="<c:url value='/video'/>" class="btn btn-outline-primary btn-sm">Video của tôi</a>
				<c:if test="${sessionScope.account.roleid == 1}">
					<a href="<c:url value='/admin/videos'/>" class="btn btn-outline-warning btn-sm">Quản trị Admin</a>
				</c:if>
			</div>

			<div class="card shadow-sm">
				<div class="card-body">
					<h3 class="card-title text-primary">${video.title}</h3>
					<p class="text-muted">
						Đăng bởi: <strong>${video.user.fullName}</strong> |
						Danh mục: <strong>${video.category.categoryname}</strong> |
						Lượt xem: <strong>${video.views}</strong>
					</p>

					<!-- Trình phát Video -->
					<div class="ratio ratio-16x9 bg-dark mb-3">
						<c:choose>
							<c:when test="${not empty video.videoUrl && video.videoUrl.startsWith('http')}">
								<iframe src="${video.videoUrl}" allowfullscreen></iframe>
							</c:when>
							<c:otherwise>
								<video controls autoplay>
									<source src="<c:url value='/media?fname=${video.videoUrl}'/>" type="video/mp4">
									Trình duyệt không hỗ trợ phát video.
								</video>
							</c:otherwise>
						</c:choose>
					</div>

					<h5>Mô tả video:</h5>
					<p>${video.description}</p>
				</div>
			</div>
		</body>

		</html>