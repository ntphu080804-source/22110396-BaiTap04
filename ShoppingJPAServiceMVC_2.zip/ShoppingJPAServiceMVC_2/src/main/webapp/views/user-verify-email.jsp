<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>
		<!DOCTYPE html>
		<html>

		<head>
			<title>Xác thực OTP Email mới</title>
		</head>

		<body>
			<div class="row justify-content-center">
				<div class="col-md-5">
					<div class="card shadow-sm">
						<div class="card-header bg-warning text-dark">
							<h5 class="mb-0">Xác Thực Email Mới</h5>
						</div>
						<div class="card-body">
							<p>Mã OTP gồm 6 chữ số đã được gửi tới địa chỉ email mới:
								<strong>${sessionScope.PROFILE_NEW_EMAIL}</strong></p>

							<c:if test="${not empty err}">
								<div class="alert alert-danger">${err}</div>
							</c:if>

							<form action="<c:url value='/user/profile/verify-email'/>" method="post">
								<div class="mb-3">
									<label class="form-label">Nhập mã OTP (6 chữ số)</label>
									<input type="text" name="otp" class="form-control text-center fw-bold fs-4"
										maxlength="6" pattern="[0-9]{6}" required placeholder="000000">
								</div>
								<button type="submit" class="btn btn-success w-100">Xác nhận cập nhật Email</button>
								<a href="<c:url value='/user/profile'/>" class="btn btn-link w-100 mt-2">Quay lại hồ
									sơ</a>
							</form>
						</div>
					</div>
				</div>
			</div>
		</body>

		</html>