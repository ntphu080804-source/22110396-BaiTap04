<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>
		<!DOCTYPE html>
		<html>

		<head>
			<meta charset="UTF-8">
			<title>Quản lý Category (JPA)</title>
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
		</head>

		<body class="container py-4">
			<!-- Thanh điều hướng chung của Admin -->
			<nav class="navbar navbar-expand-lg navbar-dark bg-primary rounded px-3 mb-4">
				<a class="navbar-brand fw-bold" href="<c:url value='/admin/categories'/>">ADMIN PANEL</a>
				<div class="navbar-nav">
					<a class="nav-link active fw-bold" href="<c:url value='/admin/categories'/>">Quản lý Danh mục</a>
					<a class="nav-link" href="<c:url value='/admin/videos'/>">Quản lý Videos</a>
					<a class="nav-link" href="<c:url value='/admin/mail-config'/>">Cấu hình Email OTP</a>
					<a class="nav-link" href="<c:url value='/home'/>">Xem Trang chủ</a>
				</div>
				<div class="ms-auto text-white">
					<span class="me-3">Admin: <strong>${sessionScope.account.fullName}</strong></span>
					<a href="<c:url value='/logout'/>" class="btn btn-danger btn-sm">Đăng xuất</a>
				</div>
			</nav>

			<div class="d-flex justify-content-between align-items-center mb-3 border-bottom pb-2">
				<h3 class="text-primary mb-0">Quản Lý Danh Mục (JPA)</h3>
			</div>

			<div class="d-flex justify-content-between mb-3">
				<a href="<c:url value='/admin/category/add'/>" class="btn btn-success">+ Add Category</a>
				<form action="<c:url value='/admin/categories'/>" method="get" class="d-flex">
					<input type="text" name="keyword" class="form-control me-2" placeholder="Tìm theo tên..."
						value="${param.keyword}">
					<button type="submit" class="btn btn-outline-primary">Tìm</button>
				</form>
			</div>

			<table class="table table-bordered table-hover align-middle">
				<thead class="table-light">
					<tr>
						<th>STT</th>
						<th>Images</th>
						<th>Category name</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<c:forEach items="${listcate}" var="cate" varStatus="STT">
						<tr>
							<td>${STT.index + 1}</td>
							<td>
								<c:choose>
									<c:when test="${not empty cate.images && cate.images.startsWith('http')}">
										<c:url value="${cate.images}" var="imgUrl" />
									</c:when>
									<c:otherwise>
										<c:url value="/image?fname=${cate.images}" var="imgUrl" />
									</c:otherwise>
								</c:choose>
								<img height="100" width="140" src="${imgUrl}" style="object-fit: cover;" />
							</td>
							<td><strong>${cate.categoryname}</strong></td>
							<td>
								<c:if test="${cate.status == 1}"><span class="badge bg-success">Hoạt động</span></c:if>
								<c:if test="${cate.status != 1}"><span class="badge bg-secondary">Khóa</span></c:if>
							</td>
							<td>
								<a href="<c:url value='/admin/category/edit?id=${cate.categoryid}'/>"
									class="btn btn-sm btn-primary">Sửa</a>
								<a href="<c:url value='/admin/category/delete?id=${cate.categoryid}'/>"
									onclick="return confirm('Xóa danh mục này?');" class="btn btn-sm btn-danger">Xóa</a>
							</td>
						</tr>
					</c:forEach>
				</tbody>
			</table>
		</body>

		</html>