<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>
		<!DOCTYPE html>
		<html lang="vi">

		<head>
			<meta charset="UTF-8">
			<title>
				<sitemesh:write property="title" default="Admin Panel" />
			</title>
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
			<sitemesh:write property="head" />
		</head>

		<body class="d-flex flex-column min-vh-100 bg-light">
			<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm mb-4">
				<div class="container">
					<a class="navbar-brand fw-bold" href="<c:url value='/admin/categories'/>">ADMIN PANEL</a>
					<div class="navbar-nav me-auto">
						<a class="nav-link" href="<c:url value='/admin/categories'/>">Quản lý Danh mục</a>
						<a class="nav-link" href="<c:url value='/admin/videos'/>">Quản lý Videos</a>
						<a class="nav-link" href="<c:url value='/admin/mail-config'/>">Cấu hình Email OTP</a>
						<a class="nav-link" href="<c:url value='/home'/>">Xem Trang chủ</a>
					</div>
					<div class="text-white">
						<span class="me-3">Admin: <strong>${sessionScope.account.fullName}</strong></span>
						<a href="<c:url value='/logout'/>" class="btn btn-danger btn-sm">Đăng xuất</a>
					</div>
				</div>
			</nav>

			<main class="container flex-grow-1 mb-5">
				<sitemesh:write property="body" />
			</main>

			<footer class="bg-primary text-white text-center py-2 mt-auto">
				<small>Hệ thống Quản trị Nội dung - Admin Dashboard</small>
			</footer>
			<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
		</body>

		</html>