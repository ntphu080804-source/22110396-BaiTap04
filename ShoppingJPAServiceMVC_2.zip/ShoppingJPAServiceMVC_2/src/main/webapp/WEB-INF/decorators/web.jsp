<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
	<%@ taglib prefix="c" uri="jakarta.tags.core" %>
		<!DOCTYPE html>
		<html lang="vi">

		<head>
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<title>
				<sitemesh:write property="title" default="Video Portal" />
			</title>
			<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
			<sitemesh:write property="head" />
		</head>

		<body class="d-flex flex-column min-vh-100 bg-light">
			<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm mb-4">
				<div class="container">
					<a class="navbar-brand fw-bold" href="<c:url value='/home'/>">VIDEO PORTAL</a>
					<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
						<span class="navbar-toggler-icon"></span>
					</button>
					<div class="collapse navbar-collapse" id="mainNav">
						<ul class="navbar-nav me-auto">
							<li class="nav-item"><a class="nav-link" href="<c:url value='/home'/>">Trang chủ</a></li>
							<c:if test="${not empty sessionScope.account}">
								<li class="nav-item"><a class="nav-link" href="<c:url value='/video'/>">Video của
										tôi</a></li>
								<li class="nav-item"><a class="nav-link" href="<c:url value='/user/profile'/>">Hồ sơ cá
										nhân</a></li>
							</c:if>
							<c:if test="${sessionScope.account.roleid == 1}">
								<li class="nav-item"><a class="nav-link text-warning fw-bold"
										href="<c:url value='/admin/videos'/>">Trang Quản Trị</a></li>
							</c:if>
						</ul>
						<div class="d-flex align-items-center text-white">
							<c:choose>
								<c:when test="${not empty sessionScope.account}">
									<c:if test="${not empty sessionScope.account.avatar}">
										<img src="${sessionScope.account.avatar}" class="rounded-circle me-2" width="32"
											height="32" style="object-fit: cover;">
									</c:if>
									<a href="<c:url value='/user/profile'/>"
										class="text-white text-decoration-none me-3">
										Xin chào, <strong>${sessionScope.account.fullName}</strong>
									</a>
									<a href="<c:url value='/logout'/>" class="btn btn-outline-danger btn-sm">Đăng
										xuất</a>
								</c:when>
								<c:otherwise>
									<a href="<c:url value='/login'/>" class="btn btn-outline-light btn-sm me-2">Đăng
										nhập</a>
									<a href="<c:url value='/register'/>" class="btn btn-primary btn-sm">Đăng ký</a>
								</c:otherwise>
							</c:choose>
						</div>
					</div>
				</div>
			</nav>

			<main class="container flex-grow-1 mb-5">
				<sitemesh:write property="body" />
			</main>

			<footer class="bg-dark text-white text-center py-3 mt-auto">
				<div class="container">
					<small>© 2026 ShoppingJPAServiceMVC_2 - Hệ thống Quản lý Video & Danh mục</small>
				</div>
			</footer>

			<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
		</body>

		</html>