package vn.iotstar.controller;

import java.io.IOException;
import java.util.Random;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import vn.iotstar.dao.IUserDao;
import vn.iotstar.dao.impl.UserDaoImpl;
import vn.iotstar.entity.User;
import vn.iotstar.util.CloudinaryUtil;
import vn.iotstar.util.EmailUtil;
import vn.iotstar.util.ValidationUtil;

@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, maxFileSize = 1024 * 1024 * 10, maxRequestSize = 1024 * 1024 * 20)
@WebServlet(urlPatterns = { "/user/profile", "/user/profile/verify-email" })
public class UserProfileController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private IUserDao userDao = new UserDaoImpl();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession(false);
		User currentUser = (session != null) ? (User) session.getAttribute("account") : null;
		if (currentUser == null) {
			resp.sendRedirect(req.getContextPath() + "/login");
			return;
		}

		String url = req.getRequestURI();
		if (url.endsWith("/verify-email")) {
			req.getRequestDispatcher("/views/user-verify-email.jsp").forward(req, resp);
		} else {
			req.getRequestDispatcher("/views/user-profile.jsp").forward(req, resp);
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		HttpSession session = req.getSession(false);
		User currentUser = (session != null) ? (User) session.getAttribute("account") : null;
		if (currentUser == null) {
			resp.sendRedirect(req.getContextPath() + "/login");
			return;
		}

		String url = req.getRequestURI();

		// Luồng 2: Xác nhận OTP cho Email mới
		if (url.endsWith("/verify-email")) {
			String inputOtp = req.getParameter("otp");
			String expectedOtp = (String) session.getAttribute("PROFILE_EMAIL_OTP");
			String pendingNewEmail = (String) session.getAttribute("PROFILE_NEW_EMAIL");

			if (expectedOtp != null && expectedOtp.equals(inputOtp != null ? inputOtp.trim() : "")) {
				currentUser.setEmail(pendingNewEmail);
				userDao.update(currentUser);
				session.setAttribute("account", currentUser);

				session.removeAttribute("PROFILE_EMAIL_OTP");
				session.removeAttribute("PROFILE_NEW_EMAIL");
				session.setAttribute("msg", "Xác thực OTP thành công! Đã cập nhật Email mới và hồ sơ.");
				resp.sendRedirect(req.getContextPath() + "/user/profile");
			} else {
				req.setAttribute("err", "Mã OTP không chính xác! Vui lòng kiểm tra lại hộp thư email mới.");
				req.getRequestDispatcher("/views/user-verify-email.jsp").forward(req, resp);
			}
			return;
		}

		// Luồng 1: Cập nhật thông tin Profile
		String fullName = req.getParameter("fullName");
		String phone = req.getParameter("phone");
		String newEmail = req.getParameter("email");

		// Server-side Validation
		if (ValidationUtil.isBlank(fullName)) {
			req.setAttribute("err", "Họ tên không được để trống!");
			req.getRequestDispatcher("/views/user-profile.jsp").forward(req, resp);
			return;
		}
		if (!ValidationUtil.isBlank(phone) && !ValidationUtil.isValidPhone(phone)) {
			req.setAttribute("err", "Số điện thoại không hợp lệ (phải gồm 10-11 chữ số, bắt đầu bằng 0 hoặc +84)!");
			req.getRequestDispatcher("/views/user-profile.jsp").forward(req, resp);
			return;
		}
		if (!ValidationUtil.isValidEmail(newEmail)) {
			req.setAttribute("err", "Định dạng Email không hợp lệ!");
			req.getRequestDispatcher("/views/user-profile.jsp").forward(req, resp);
			return;
		}

		try {
			// Upload ảnh  diện lên Cloudinary nếu người dùng có chọn file mới
			Part imagePart = req.getPart("imageFile");
			if (imagePart != null && imagePart.getSize() > 0) {
				String cloudUrl = CloudinaryUtil.uploadImage(imagePart);
				if (cloudUrl != null) {
					currentUser.setAvatar(cloudUrl);
				}
			}

			currentUser.setFullName(fullName.trim());
			currentUser.setPhone(phone != null ? phone.trim() : null);

			String oldEmail = currentUser.getEmail();
			newEmail = newEmail.trim();

			// Kiểm tra xem người dùng có đổi sang Email mới không
			if (!newEmail.equalsIgnoreCase(oldEmail)) {
				if (userDao.checkExistEmail(newEmail)) {
					req.setAttribute("err", "Email mới này đã được sử dụng bởi tài khoản khác!");
					req.getRequestDispatcher("/views/user-profile.jsp").forward(req, resp);
					return;
				}

				// Lưu trước fullname, phone, images; riêng email mới chờ xác thực OTP
				userDao.update(currentUser);
				session.setAttribute("account", currentUser);

				String otp = String.format("%06d", new Random().nextInt(999999));
				boolean sent = EmailUtil.sendOTP(newEmail, "Xác nhận thay đổi Email Profile", otp);
				if (sent) {
					session.setAttribute("PROFILE_EMAIL_OTP", otp);
					session.setAttribute("PROFILE_NEW_EMAIL", newEmail);
					resp.sendRedirect(req.getContextPath() + "/user/profile/verify-email");
				} else {
					req.setAttribute("err",
							"Đã lưu thông tin khác nhưng không thể gửi OTP tới email mới. Kiểm tra lại SMTP!");
					req.getRequestDispatcher("/views/user-profile.jsp").forward(req, resp);
				}
			} else {
				// Không đổi email -> Cập nhật hoàn tất ngay
				userDao.update(currentUser);
				session.setAttribute("account", currentUser);
				req.setAttribute("msg", "Cập nhật thông tin cá nhân thành công!");
				req.getRequestDispatcher("/views/user-profile.jsp").forward(req, resp);
			}
		} catch (Exception e) {
			e.printStackTrace();
			req.setAttribute("err", "Lỗi xử lý cập nhật hồ sơ: " + e.getMessage());
			req.getRequestDispatcher("/views/user-profile.jsp").forward(req, resp);
		}
	}
}