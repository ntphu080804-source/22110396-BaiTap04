package vn.iotstar.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import vn.iotstar.entity.User;
import vn.iotstar.service.IUserService;
import vn.iotstar.service.impl.UserServiceImpl;
import vn.iotstar.util.Constant;

@WebServlet(urlPatterns = { "/login", "/register", "/verify-otp", "/forgot-password", "/reset-password", "/waiting",
		"/logout" })
public class AuthController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private IUserService userService = new UserServiceImpl();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String url = req.getRequestURI();
		if (url.contains("/login")) {
			String auto = userService.checkAutoLogin(req);
			if (auto != null) {
				resp.sendRedirect(req.getContextPath() + auto);
				return;
			}
			req.getRequestDispatcher("/views/login.jsp").forward(req, resp);
		} else if (url.contains("/register")) {
			req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
		} else if (url.contains("/verify-otp")) {
			req.getRequestDispatcher("/views/verify-otp.jsp").forward(req, resp);
		} else if (url.contains("/forgot-password")) {
			req.getRequestDispatcher("/views/forgot-password.jsp").forward(req, resp);
		} else if (url.contains("/reset-password")) {
			req.getRequestDispatcher("/views/reset-password.jsp").forward(req, resp);
		} else if (url.contains("/waiting")) {
			HttpSession session = req.getSession(false);
			User u = (session != null) ? (User) session.getAttribute("account") : null;
			resp.sendRedirect(userService.getRedirectUrlByRole(u, req.getContextPath()));
		} else if (url.contains("/logout")) {
			req.getSession().invalidate();
			Cookie cookie = new Cookie(Constant.COOKIE_REMEMBER, "");
			cookie.setMaxAge(0);
			cookie.setPath("/");
			resp.addCookie(cookie);
			resp.sendRedirect(req.getContextPath() + "/login");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		String url = req.getRequestURI();

		if (url.contains("/login")) {
			String err = userService.processLogin(req.getParameter("username"), req.getParameter("password"),
					"on".equals(req.getParameter("remember")), req, resp);
			if (err == null) {
				resp.sendRedirect(req.getContextPath() + "/waiting");
			} else {
				req.setAttribute("alert", err);
				req.getRequestDispatcher("/views/login.jsp").forward(req, resp);
			}
		} else if (url.contains("/register")) {
			String email = req.getParameter("email");
			String err = userService.registerWithOTP(req.getParameter("username"), req.getParameter("password"), email,
					req.getParameter("fullname"), req.getParameter("phone"));
			if (err == null) {
				req.getSession().setAttribute("pendingEmail", email);
				req.getRequestDispatcher("/views/verify-otp.jsp").forward(req, resp);
			} else {
				req.setAttribute("alert", err);
				req.getRequestDispatcher("/views/register.jsp").forward(req, resp);
			}
		} else if (url.contains("/verify-otp")) {
			String email = (String) req.getSession().getAttribute("pendingEmail");
			String otp = req.getParameter("otp");
			if (email != null && userService.verifyRegisterOTP(email, otp)) {
				req.getSession().removeAttribute("pendingEmail");
				req.setAttribute("message", "Kích hoạt tài khoản thành công! Vui lòng đăng nhập.");
				req.getRequestDispatcher("/views/login.jsp").forward(req, resp);
			} else {
				req.setAttribute("alert", "Mã OTP không đúng!");
				req.getRequestDispatcher("/views/verify-otp.jsp").forward(req, resp);
			}
		} else if (url.contains("/forgot-password")) {
			String email = req.getParameter("email");
			String err = userService.sendForgotPasswordOTP(email);
			if (err == null) {
				req.getSession().setAttribute("resetEmail", email);
				req.getRequestDispatcher("/views/reset-password.jsp").forward(req, resp);
			} else {
				req.setAttribute("alert", err);
				req.getRequestDispatcher("/views/forgot-password.jsp").forward(req, resp);
			}
		} else if (url.contains("/reset-password")) {
			String email = (String) req.getSession().getAttribute("resetEmail");
			String otp = req.getParameter("otp");
			String newPass = req.getParameter("newPassword");
			String err = userService.resetPasswordWithOTP(email, otp, newPass);
			if (err == null) {
				req.getSession().removeAttribute("resetEmail");
				req.setAttribute("message", "Đổi mật khẩu thành công! Vui lòng đăng nhập.");
				req.getRequestDispatcher("/views/login.jsp").forward(req, resp);
			} else {
				req.setAttribute("alert", err);
				req.getRequestDispatcher("/views/reset-password.jsp").forward(req, resp);
			}
		}
	}
}