package vn.iotstar.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import vn.iotstar.util.Constant;

@WebServlet(urlPatterns = { "/image", "/media" })
public class DownloadImageController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String fileName = req.getParameter("fname");
		if (fileName != null) {
			File file = new File(Constant.DIR + "/" + fileName);
			if (file.exists()) {
				if (fileName.endsWith(".mp4")) {
					resp.setContentType("video/mp4");
				} else {
					resp.setContentType("image/jpeg");
				}
				resp.setContentLengthLong(file.length());
				try (FileInputStream fis = new FileInputStream(file); OutputStream os = resp.getOutputStream()) {
					byte[] buffer = new byte[8192];
					int bytesRead;
					while ((bytesRead = fis.read(buffer)) != -1) {
						os.write(buffer, 0, bytesRead);
					}
				}
			}
		}
	}
}