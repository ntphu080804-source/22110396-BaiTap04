package vn.iotstar.service;

import java.util.List;
import jakarta.servlet.http.HttpServletRequest;
import vn.iotstar.entity.User;
import vn.iotstar.entity.Video;

public interface IVideoService {
	List<Video> findAll();

	List<Video> findTop10Newest();

	List<Video> findByUserId(int userId, int page, int pageSize);

	int countByUserId(int userId);

	Video findById(String videoId);

	Video watchVideo(String videoId);

	void delete(String videoId) throws Exception;

	void processInsert(HttpServletRequest req, User currentUser);

	void processUpdate(HttpServletRequest req);
}