package vn.iotstar.service;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import vn.iotstar.entity.User;

public interface IUserService {
	String processLogin(String username, String password, boolean isRememberMe, HttpServletRequest req,
			HttpServletResponse resp);

	String checkAutoLogin(HttpServletRequest req);

	String getRedirectUrlByRole(User user, String contextPath);

	String registerWithOTP(String username, String password, String email, String fullname, String phone);

	boolean verifyRegisterOTP(String email, String otpInput);

	String sendForgotPasswordOTP(String email);

	String resetPasswordWithOTP(String email, String otpInput, String newPassword);
}