package vn.iotstar.util;

public class Constant {
	public static final String DIR = "D:\\upload";
	public static final String COOKIE_REMEMBER = "username";
	public static final String DEFAULT_FILENAME = "default.file";

	// Cấu hình Gmail SMTP gửi OTP (Dùng Mật khẩu ứng dụng - App Password 16 ký tự
	// của Google)
	public static final String SMTP_HOST = "smtp.gmail.com";
	public static final String SMTP_PORT = "587";
	public static final String EMAIL_FROM = "ntp558507@gmail.com"; // Thay bằng Gmail của bạn
	public static final String EMAIL_PASSWORD = "xxxx xxxx xxxx xxxx"; // Thay bằng App Password
}