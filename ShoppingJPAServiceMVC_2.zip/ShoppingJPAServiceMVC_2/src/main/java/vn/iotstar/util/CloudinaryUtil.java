package vn.iotstar.util;

import java.io.InputStream;
import java.util.Map;
import java.util.Properties;
import com.cloudinary.Cloudinary;
import com.cloudinary.utils.ObjectUtils;
import jakarta.servlet.http.Part;

public class CloudinaryUtil {
	private static Cloudinary cloudinary;

	static {
		try (InputStream is = CloudinaryUtil.class.getClassLoader().getResourceAsStream("config.properties")) {
			Properties props = new Properties();
			if (is != null)
				props.load(is);
			cloudinary = new Cloudinary(
					ObjectUtils.asMap("cloud_name", props.getProperty("cloudinary.cloud_name", "").trim(), "api_key",
							props.getProperty("cloudinary.api_key", "").trim(), "api_secret",
							props.getProperty("cloudinary.api_secret", "").trim(), "secure", true));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public static String uploadImage(Part filePart) throws Exception {
		if (filePart == null || filePart.getSize() == 0)
			return null;
		byte[] fileBytes = filePart.getInputStream().readAllBytes();
		Map<String, Object> uploadResult = cloudinary.uploader().upload(fileBytes,
				ObjectUtils.asMap("folder", "user_avatars", "resource_type", "image"));
		return (String) uploadResult.get("secure_url");
	}
}