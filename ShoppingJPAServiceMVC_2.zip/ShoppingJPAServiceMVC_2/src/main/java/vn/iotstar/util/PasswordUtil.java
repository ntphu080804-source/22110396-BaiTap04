package vn.iotstar.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Random;

public class PasswordUtil {
	public static String hashPassword(String plainPassword) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			byte[] hash = md.digest(plainPassword.getBytes(StandardCharsets.UTF_8));
			return Base64.getEncoder().encodeToString(hash);
		} catch (Exception e) {
			throw new RuntimeException("Lỗi mã hóa mật khẩu", e);
		}
	}

	public static boolean checkPassword(String plainPassword, String hashedPassword) {
		if (plainPassword == null || hashedPassword == null)
			return false;
		return hashPassword(plainPassword).equals(hashedPassword);
	}

	public static String generateOTP() {
		Random rnd = new Random();
		int number = 100000 + rnd.nextInt(900000);
		return String.valueOf(number);
	}
}