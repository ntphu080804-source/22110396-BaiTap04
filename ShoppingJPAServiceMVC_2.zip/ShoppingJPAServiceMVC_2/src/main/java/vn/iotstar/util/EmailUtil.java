package vn.iotstar.util;

import java.io.InputStream;
import java.util.Properties;
import jakarta.mail.*;
import jakarta.mail.internet.*;

public class EmailUtil {

	private static Properties loadMailProperties() {
		Properties props = new Properties();
		try (InputStream is = EmailUtil.class.getClassLoader().getResourceAsStream("config.properties")) {
			if (is != null) {
				props.load(is);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return props;
	}

	public static boolean sendOTP(String toEmail, String subject, String otpCode) {
		try {
			Properties props = loadMailProperties();
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.ssl.trust", "smtp.gmail.com");

			final String username = props.getProperty("mail.smtp.username", "").trim();
			final String password = props.getProperty("mail.smtp.password", "").replaceAll("\\s+", "");

			System.out.println(">>> Đang gửi mail từ: [" + username + "] | Độ dài pass: " + password.length());

			Session session = Session.getInstance(props, new Authenticator() {
				@Override
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(username, password);
				}
			});

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(username, "Video Portal System", "UTF-8"));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
			message.setSubject(MimeUtility.encodeText(subject, "UTF-8", "B"));

			String htmlContent = "<div style='font-family: Arial, sans-serif; padding: 20px; border: 1px solid #ddd; border-radius: 8px;'>"
					+ "<h3 style='color: #0d6efd;'>Mã xác thực OTP của bạn</h3>"
					+ "<p>Vui lòng nhập mã OTP gồm 6 chữ số dưới đây để hoàn tất xác thực:</p>"
					+ "<h2 style='background: #f8f9fa; padding: 12px 24px; display: inline-block; letter-spacing: 6px; color: #dc3545; border: 1px dashed #dc3545;'>"
					+ otpCode + "</h2>"
					+ "<p style='color: #6c757d; font-size: 13px;'>Không chia sẻ mã này cho bất kỳ ai.</p>" + "</div>";

			message.setContent(htmlContent, "text/html; charset=UTF-8");
			Transport.send(message);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
}